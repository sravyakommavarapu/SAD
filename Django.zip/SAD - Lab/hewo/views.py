from django.shortcuts import render
from django.http import JsonResponse
from django.views import View

def getRoutes(request):
	return JsonResponse('Hello World!', safe=False)