from django.urls import path 
from hewo import views

urlpatterns = [
 path('', views.getRoutes, name='routes'),
]