Initially, python is downloaded in the visual studio.
A folder in which app to be developed is created.
With the help of pip command django is installed successfully.
The server is activated and using run server is entered.
Link created is opened. 
Hello word app is created.
With the help of run server app is viewed and link developed in this was http://127.0.0.1:8000/.
